package ex1;

public class Confirmacao {
	private Integer codigo;
	private String mensagem;
	
	public Confirmacao() {
		this.codigo = 200;
		this.mensagem = null;
	}
	
	public Confirmacao(String mensagem) {
		this.codigo = 500;
		this.mensagem = mensagem;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}
	
	public String getMensagem() {
		return this.mensagem;
	}
	
	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}	
}