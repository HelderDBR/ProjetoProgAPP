package ex1;

import java.io.*;
import java.net.*;

import com.google.gson.*;

public class EchoClient {
    public static void main(String[] args) throws IOException {

    	InetAddress localAddress = InetAddress.getLocalHost();
        String serverHostname = new String ("192.168.1.8");
        int port = 10007;
        if (args.length > 0)
           serverHostname = args[0];
        
        System.out.println ("Tentando conectar ao host " +
		serverHostname + " na porta " + port);
        
        Socket socket = null;
        PrintWriter clientMessage = null;
        BufferedReader serverMessage = null;

        try {
            socket = new Socket(serverHostname, port);
            clientMessage = new PrintWriter(socket.getOutputStream(), true);
            serverMessage = new BufferedReader(new InputStreamReader(
                                        socket.getInputStream()));
        } catch (UnknownHostException e) {
            System.err.println("Host não encontrado: " + serverHostname);
            System.exit(1);
        } catch (IOException e) {
            System.err.println("Não foi possível pegar o I/O "
                               + "da conexão com: " + serverHostname);
            System.exit(1);
        }

		BufferedReader stdIn = new BufferedReader(
	                                   new InputStreamReader(System.in));
		
		String userInput;
		
		String menu = "-----Menu-----\n1 - Cadastrar\n2 - Login\n0 - Desconectar";
	
		System.out.println(menu);
		Gson gson = new Gson();
		boolean flagLogado = false;
		String temp;
		
		while ((userInput = stdIn.readLine()) != null) {
			switch(userInput) {
				case "0":
					System.out.println("Logout >> Certeza que quer se desconectar? S/N");
					temp = stdIn.readLine();
					
					if(temp.equals("S")) {
						clientMessage.close();
						serverMessage.close();
						stdIn.close();
						socket.close();
						
						return;
					}
					
					System.out.println("Bem vindo de volta!");
					
					System.out.println(menu);
					
					break;
					
				case "1":
					System.out.println("Cadastro >> Nome:");
					String nome = stdIn.readLine();
					
					System.out.println("Cadastro >> Email:");
					String email = stdIn.readLine();
					
					System.out.println("Cadastro >> Senha:");
					String senha = stdIn.readLine();
					senha = hashed(senha);
					
					//convertendo obj em json
					Usuario usuario = new Usuario(1, nome, email, senha);
					String usuarioJson = gson.toJson(usuario);
					
					//mandando msg do cliente
					clientMessage.println(usuarioJson);
				    System.out.println("Enviado: " + usuarioJson);
					
				    //lendo e printando msg do servidor
				    String respostaJson = serverMessage.readLine();
				    System.out.println("Recebido: " + respostaJson);
				    
					break;
				
				case "2":
					if(flagLogado) {
						System.out.println("Você já está logado.");
						return;
					}
					
					System.out.println("Login >> Email:");
					email = stdIn.readLine();
					
					System.out.println("Login >> Senha:");
					senha = stdIn.readLine();
					senha = hashed(senha);
					
					usuario = new Usuario(3, null, email, senha);
					usuarioJson = gson.toJson(usuario);
					
					clientMessage.println(usuarioJson);
					System.out.println("Enviado: " + usuarioJson);
					
					respostaJson = serverMessage.readLine();
				    System.out.println("Recebido: " + respostaJson);
				    
				    Confirmacao resposta = gson.fromJson(respostaJson, Confirmacao.class);
					
				    if(resposta.getCodigo().equals(200)){
						menu = "-----Menu-----\n1 - Cadastrar\n2 - Login\n3 - Logout\n0 - Desconectar";
						System.out.println(menu);
						System.out.println("Bem-vindo!");
				    }else {
				    	System.out.println(resposta.getMensagem());
				    }
				    
				    flagLogado = true;
				    
					break;
					
				case "3":
					System.out.println("Logout >> Certeza que quer sair? S/N");
					temp = stdIn.readLine();
					
					if(temp.equals("S")) {
						menu = "-----Menu-----\n1 - Cadastrar\n2 - Login\n0 - Desconectar";
						System.out.println(menu);
						
						flagLogado = false;
						
						return;
					}
					
					System.out.println("Bem vindo de volta!");
					
					System.out.println(menu);
					
					break;
			}	    
			
		}
	
		
	    }
    
    public static String hashed(String pswd) {
    	
    	String hashed = "";
    	
        for (int i = 0; i < pswd.length(); i++) {
            char c = pswd.charAt(i);
            int asciiValue = (int) c;
            int novoAsciiValue = asciiValue + pswd.length();
            if (novoAsciiValue > 127) {
                novoAsciiValue = novoAsciiValue - 127 + 32;
            }
            char novoCaractere = (char) novoAsciiValue;
            hashed += novoCaractere;
        }
        return hashed;
    }
}